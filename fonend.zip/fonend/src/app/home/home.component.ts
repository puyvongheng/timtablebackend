import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  studentDetails: any = null;
  constructor(private authService: AuthService) { }


  // Calculate year minus 2007
  getYearMinus2007() {
    const date = this.studentDetails.date_joined ? new Date(this.studentDetails.date_joined) : null;
    if (date) {
      return date.getFullYear() - 2007; // Subtract 2007 from the year
    }
    return 0;
  }
  getYear() {
    // Make sure that 'this.yyyynow' is a valid Date object.
    const currentDate = new Date(); // Get the current date
    return currentDate.getFullYear() - 2007; // Subtract 2007 from the current year
  }



  // Method to log out the user
  logout() {
    this.authService.logout();  // Call the logout method from AuthService
  }

  ngOnInit() {

    // Get student details from localStorage (or sessionStorage)
    const storedStudentDetails = localStorage.getItem('studentDetails');
    if (storedStudentDetails) {
      this.studentDetails = JSON.parse(storedStudentDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }
  }


}