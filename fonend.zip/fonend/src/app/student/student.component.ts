import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { ManagementStudenRegisterComponent } from "../management-studen-register/management-studen-register.component";

@Component({
  selector: 'app-student',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, NzPaginationModule, ManagementStudenRegisterComponent],
  templateUrl: './student.component.html',
  styleUrl: './student.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line

})

export class StudentComponent implements OnInit {
  students: any[] = []; // Array to hold students data
  majors: any[] = [];   // Array to hold majors data from the API
  studentId: number | null = null; // ID of the student being edited
  username: string = '';
  name: string = '';
  password: string = '';
  majorId: number | null = null;
  generation: string = '';
  batch: string = '';
  groupStudent: string = '';

  totalStudents: number = 0;
  currentPage: number = 1;
  pageSize: number = 10;
  message: any;


  onPageChange(page: number): void {
    // Save the current page number to localStorage when the page changes
    localStorage.setItem('currentPage', page.toString());
    this.currentPage = page;
    this.loadStudents(this.currentPage, this.pageSize);  // Re-fetch students based on the new page number
  }

  // Call this function when the page size changes
  onPageSizeChange(pageSize: number): void {
    // Update the page size
    this.pageSize = pageSize;
    // Recalculate the current page if the total number of students has changed
    const totalPages = Math.ceil(this.totalStudents / this.pageSize);
    // If the current page is greater than the total pages after changing the page size, reset to the last available page
    if (this.currentPage > totalPages) {
      this.currentPage = totalPages;
    }
    // Re-fetch students based on the new page size and adjusted current page
    this.loadStudents(this.currentPage, this.pageSize);
  }

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {

    this.loadStudents(this.currentPage, this.pageSize); // Load students on component init

    this.loadStudents(); // Load students when the component initializes

    this.loadMajors();   // Load majors when the component initializes


  }


  loadStudents(page: number = 1, pageSize: number = 10): void {
    // Get the saved page number from localStorage (if exists), otherwise use the provided default
    const savedPage = localStorage.getItem('currentPage');
    this.currentPage = savedPage ? +savedPage : page; // Use saved page or default to 1

    this.apiService.getstuden('students', this.currentPage, pageSize).subscribe(
      (data) => {
        this.students = data.students; // Assuming the API sends students in this format
        this.totalStudents = data.totalStudents; // Assuming API sends total number of students
      },
      (error) => {
        console.error('Error loading students:', error);
      }
    );
  }

  // Fetch all students
  loadStudentss(): void {
    this.apiService.get('students').subscribe((response: any) => {
      this.students = response;
    });
  }

  // Fetch all majors
  loadMajors(): void {
    this.apiService.get('majors').subscribe((response: any) => {
      this.majors = response;
    });
  }

  // Add a new student
  addStudent(): void {
    if (this.username && this.name && this.password && this.majorId) {
      const newStudent = {
        username: this.username,
        name: this.name,
        password: this.password,
        major_id: this.majorId,
        generation: this.generation,
        batch: this.batch,
        group_student: this.groupStudent
      };

      this.apiService.create('students', newStudent).subscribe(() => {
        this.loadStudents(); // Reload students after adding
        this.resetForm(); // Reset the form after adding
      });
    } else {
      alert('All fields are required!');
    }
  }

  // Update existing student
  editStudent(id: number): void {
    const student = this.students.find(student => student.id === id);
    if (student) {
      this.studentId = student.id;
      this.username = student.username;
      this.name = student.name;
      this.password = student.password;
      this.majorId = student.major_id;
      this.generation = student.generation;
      this.batch = student.batch;
      this.groupStudent = student.group_student;
    }
  }

  // Method to update a student's data
  updateStudent(): void {
    if (this.studentId) {
      const updatedStudent = {
        username: this.username,
        name: this.name,
        password: this.password,
        major_id: this.majorId,
        generation: this.generation,
        batch: this.batch,
        group_student: this.groupStudent
      };

      this.apiService.update('students', this.studentId, updatedStudent).subscribe(
        () => {
          // Success: Reload students after updating
          this.loadStudents();
          this.resetForm();
          // Show success alert
          alert('Student updated successfully!');
        },
        (error) => {
          // Error: Handle the error and show the message
          console.error('Error updating student:', error);
          alert('An error occurred while updating the student.');
        }
      );
    }
  }




  // Delete a student
  deleteStudent(id: number): void {
    if (confirm('Are you sure you want to delete this student?')) {
      this.apiService.delete('students', id).subscribe(() => {
        // After deleting, we need to check if the current page still has students
        const newTotalStudents = this.totalStudents - 1;

        // If current page has no students, go to the previous page (or stay on the current page if it's the first page)
        if (newTotalStudents <= (this.currentPage - 1) * this.pageSize) {
          this.currentPage = Math.max(1, this.currentPage - 1);  // Avoid going to page 0
        }

        this.totalStudents = newTotalStudents;
        this.loadStudents(this.currentPage, this.pageSize); // Reload students on the new page
      });
    }
  }



  // Reset the form
  resetForm(): void {
    this.studentId = null;
    this.username = '';
    this.name = '';
    this.password = '';
    this.majorId = null;
    this.generation = '';
    this.batch = '';
    this.groupStudent = '';
  }
}