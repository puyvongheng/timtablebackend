import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzIconModule } from 'ng-zorro-antd/icon';



@Component({
  selector: 'app-navbar',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, NzMenuModule, NzSwitchModule, NzIconModule, NzToolTipModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {


  // Login method to simulate login action



  studentDetails: any = null;
  teacherDetails: any = null;
  constructor(private authService: AuthService) { }


  // Method to log out the user
  logout() {
    this.authService.logout();  // Call the logout method from AuthService
    //window.location.reload();  // This reloads the page

  }

  ngOnInit() {




    const storedTeacherDetails = localStorage.getItem('teacherDetails');
    if (storedTeacherDetails) {
      this.teacherDetails = JSON.parse(storedTeacherDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }



    // Get student details from localStorage (or sessionStorage)
    const storedStudentDetails = localStorage.getItem('studentDetails');
    if (storedStudentDetails) {
      this.studentDetails = JSON.parse(storedStudentDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }
  }

}
