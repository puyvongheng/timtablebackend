import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { TeacherListComponent } from './teacher-list/teacher-list.component';
import { HomeComponent } from './home/home.component';
import { TimetableComponent } from './timetable/timetable.component';
import { PrintComponent } from './print/print.component';
import { LoginTeacherComponent } from './login-teacher/login-teacher.component';
import { CreateTimetableComponent } from './create-timetable/create-timetable.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManagementComponent } from './management/management.component';
import { DepartmentComponent } from './department/department.component';
import { StudentComponent } from './student/student.component';
import { MajorComponent } from './major/major.component';
import { FacultyComponent } from './faculty/faculty.component';
import { StudySessionComponent } from './study-session/study-session.component';
import { TimetablesComponent } from './timetables/timetables.component';
import { EditTimetableComponent } from './edit-timetable/edit-timetable.component';
import { TimetablesPublicComponent } from './timetables-public/timetables-public.component';
import { ProfileComponent } from './profile/profile.component';
import { PrintTeacherComponent } from './print-teacher/print-teacher.component';
import { ManagementTeacherComponent } from './management-teacher/management-teacher.component';
import { RoomComponent } from './room/room.component';
import { StudySessionsComponent } from './study-sessions/study-sessions.component';

export const routes: Routes = [
    { path: '', redirectTo: '/Profile', pathMatch: 'full' },  // Redirect the default path to login
    { path: 'login', component: LoginComponent },
    { path: 'loginteacher', component: LoginTeacherComponent },           // Define the login route
    // Define the login route
    { path: 'home', component: HomeComponent },
    { path: 'teachers', component: TeacherListComponent },
    { path: 'Profile', component: ProfileComponent },
    { path: 'print', component: PrintComponent },
    { path: 'printTeacher', component: PrintTeacherComponent },


    { path: 'create_timetable', component: CreateTimetableComponent },

    { path: 'dashboard', component: DashboardComponent },
    { path: 'management', component: ManagementComponent },

    { path: 'department', component: DepartmentComponent },
    { path: 'room', component: RoomComponent },
    { path: 'studysession', component: StudySessionComponent },
    { path: 'studysessions', component: StudySessionsComponent },





    { path: 'students', component: StudentComponent },
    { path: 'major', component: MajorComponent },
    { path: 'facultie', component: FacultyComponent },
    { path: 'studysession', component: StudySessionComponent },
    { path: 'timetables', component: TimetablesComponent },
    { path: 'timetables/edit/:id', component: EditTimetableComponent },
    { path: 't', component: TimetablesPublicComponent },
    { path: 'management - teacher', component: ManagementTeacherComponent },






];