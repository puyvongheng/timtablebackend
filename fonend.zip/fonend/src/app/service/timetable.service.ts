import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TimetableService {
  private API_BASE_URL = 'http://127.0.0.1:5000/api/timetable/filter';
  private MAJOR_API_URL = 'http://127.0.0.1:5000/api/majors';
  private STUDY_SESSION_API_URL = 'http://127.0.0.1:5000/api/study_sessions'; // Endpoint for study sessions

  constructor(private http: HttpClient) { }






  private apiBaseUrl = 'http://127.0.0.1:5000/api';

  // Fetch study sessions
  getStudySessions(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiBaseUrl}/study_sessions`);
  }

  // Fetch majors
  getMajors(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiBaseUrl}/majors`);
  }



  // Fetch teachers
  getTeachers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiBaseUrl}/teachers`);
  }

  // Fetch subjects
  getSubjects(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiBaseUrl}/subjects`);
  }

  // Fetch rooms
  getRooms(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiBaseUrl}/rooms`);
  }

  // Create timetable entry
  createTimetable(timetableData: any): Observable<any> {
    return this.http.post<any>(`${this.apiBaseUrl}/timetable`, timetableData);
  }

  // Fetch timetable data with filters
  getTimetable(
    majorId?: string,
    batch?: string,
    years?: number,
    semester?: number,
    generation?: string,
    shiftName?: string  // Add shiftName parameter
  ): Observable<any> {
    let params = new HttpParams();
    if (majorId) params = params.append('major_id', majorId);
    if (batch) params = params.append('batch', batch);
    if (years) params = params.append('years', years.toString());
    if (semester) params = params.append('semester', semester.toString());
    if (generation) params = params.append('generation', generation);
    if (shiftName) params = params.append('shift_name', shiftName); // Include shiftName filter

    return this.http.get(this.API_BASE_URL, { params });
  }





}
