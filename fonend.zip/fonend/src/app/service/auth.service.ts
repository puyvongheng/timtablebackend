import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = `http://127.0.0.1:5000/api/students`;  // Adjust the API URL according to your backend
  private apiUrlteachers = `http://127.0.0.1:5000/api/teachers`;  // Adjust the API URL according to your backend

  constructor(private http: HttpClient, private router: Router) { }

  // Login method for  studen
  login(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, { username, password });
  }
  //login tacher
  login_tacher(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrlteachers}/login`, { username, password });
  }


  // Logout method
  logout() {
    localStorage.removeItem('token');  // Remove the token from localStorage
    localStorage.removeItem('studentDetails');  // Remove user details from localStorage
    localStorage.removeItem('teacherDetails');  // Remove user details from localStorage
    //  window.location.reload();  // This reloads the page

    // this.router.navigate(['/login']);  // Redirect user to login page
    this.router.navigate(['/login']);

    setTimeout(() => {
      window.location.reload();  // Reload the page
      this.router.navigate(['/login']);  // Redirect user to the login page
    }, 100);  // 10-second delay before reloading and navigating
    //  window.location.reload();

  }

  // Save the token to localStorage (or sessionStorage) after login
  saveToken(token: string): void {
    localStorage.setItem('authToken', token); // Save JWT token
  }

  // Check if the user is logged in (by checking for token)
  isLoggedIn(): boolean {
    return !!localStorage.getItem('authToken'); // Check if token exists
  }

  // Get the stored token (if needed)
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }
}
