import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private baseUrl: string = 'http://127.0.0.1:5000/api/';

  constructor(private http: HttpClient) { }

  checkUsernameAvailability(username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}teachers/username/${username}`);
  }


  assignSubjectToTeacher(teacherId: number, subjectId: number): Observable<any> {
    const data = {
      teacher_id: teacherId,
      subject_id: subjectId
    };
    return this.create('teacher_subjects', data);
  }

  deleteTeacherSubject(teacherId: number, subjectId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}teacher_subjects`, {
      body: { teacher_id: teacherId, subject_id: subjectId }
    });
  }

  // Generic GET method to fetch resources with pagination
  getstuden(endpoint: string, page: number = 1, pageSize: number = 10): Observable<any> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    return this.http.get(`${this.baseUrl}${endpoint}`, { params });
  }




  // Generic GET method to fetch resources
  get(endpoint: string): Observable<any> {
    return this.http.get(`${this.baseUrl}${endpoint}`);
  }

  
  // Generic POST, PUT, DELETE Methods for various endpoints
  create(endpoint: string, data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}${endpoint}`, data);
  }


  update(endpoint: string, id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}/${id}`, data);
  }

  updatrole(endpoint: string, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}`, data);
  }


  delete(endpoint: string, id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}${endpoint}/${id}`);
  }



  // Fetch Majors
  getMajors(): Observable<any> {
    return this.http.get(`${this.baseUrl}majors`);
  }








  // Fetch Faculties
  getFaculties(): Observable<any> {
    return this.http.get(`${this.baseUrl}faculties`);
  }
  createFaculties(endpoint: string, data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}${endpoint}`, data);
  }

  updateFaculties(endpoint: string, id: number, data: any): Observable<any> {
    return this.http.put(`${this.baseUrl}${endpoint}/${id}`, data);
  }

  deleteFaculties(endpoint: string, id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}${endpoint}/${id}`);
  }





  // Fetch Departments
  getDepartments(): Observable<any> {
    return this.http.get(`${this.baseUrl}departments`);
  }

  // Fetch Rooms
  getRooms(): Observable<any> {
    return this.http.get(`${this.baseUrl}rooms`);
  }

  // Fetch Students
  getStudents(): Observable<any> {
    return this.http.get(`${this.baseUrl}students`);
  }

  // Fetch Study Sessions
  getStudySessions(): Observable<any> {
    return this.http.get(`${this.baseUrl}study_sessions`);
  }

  // Fetch Subjects
  getSubjects(): Observable<any> {
    return this.http.get(`${this.baseUrl}subjects`);
  }

  // Fetch Teacher Subjects
  getTeacherSubjects(): Observable<any> {
    return this.http.get(`${this.baseUrl}teacher_subjects`);
  }

  // Fetch Teachers
  getTeachers(): Observable<any> {
    return this.http.get(`${this.baseUrl}teachers`);
  }

  // Fetch Timetable
  getTimetable(): Observable<any> {
    return this.http.get(`${this.baseUrl}timetable`);
  }

}
