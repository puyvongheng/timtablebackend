import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-room',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule],
  templateUrl: './room.component.html',
  styleUrl: './room.component.css'
})
export class RoomComponent implements OnInit {
  rooms: any[] = []; // Array to hold room data
  roomNumber: string = ''; // Room number input
  capacity: number | null = null; // Room capacity input
  floor: number | null = null; // Room floor input
  roomType: string = ''; // Room type input
  selectedRoomId: number | null = null; // The selected room for editing

  constructor(private apiService: ApiService) { }


  ngOnInit(): void {
    this.loadRooms(); // Load rooms when the component initializes
  }

  // Fetch all rooms
  loadRooms(): void {
    this.apiService.get('rooms').subscribe((response) => {
      this.rooms = response;
    });
  }

  // Add a new room
  addRoom(): void {
    if (this.roomNumber.trim() && this.capacity && this.floor && this.roomType) {
      const newRoom = {
        room_number: this.roomNumber,
        capacity: this.capacity,
        floor: this.floor,
        room_type: this.roomType
      };

      this.apiService.create('rooms', newRoom).subscribe(
        () => {
          this.loadRooms(); // Reload rooms after adding
          this.clearForm(); // Clear the form
        },
        (error) => {
          console.error('Error adding room:', error);
        }
      );
    } else {
      alert('Please provide all room details!');
    }
  }

  // Edit a room
  editRoom(id: number): void {
    const room = this.rooms.find(r => r.id === id);
    if (room) {
      this.selectedRoomId = id;
      this.roomNumber = room.room_number;
      this.capacity = room.capacity;
      this.floor = room.floor;
      this.roomType = room.room_type;
    }
  }

  // Update an existing room
  updateRoom(): void {
    if (this.selectedRoomId && this.roomNumber.trim() && this.capacity && this.floor && this.roomType) {
      const updatedRoom = {
        room_number: this.roomNumber,
        capacity: this.capacity,
        floor: this.floor,
        room_type: this.roomType
      };

      this.apiService.update('rooms', this.selectedRoomId, updatedRoom).subscribe(
        () => {
          this.loadRooms(); // Reload rooms after update
          this.clearForm(); // Clear the form
          this.selectedRoomId = null; // Reset selected room ID
        },
        (error) => {
          console.error('Error updating room:', error);
        }
      );
    }
  }

  // Delete a room
  deleteRoom(id: number): void {
    if (confirm('Are you sure you want to delete this room?')) {
      this.apiService.delete('rooms', id).subscribe(
        () => {
          this.loadRooms(); // Reload rooms after deletion
        },
        (error) => {
          console.error('Error deleting room:', error);
        }
      );
    }
  }

  // Clear form inputs
  clearForm(): void {
    this.roomNumber = '';
    this.capacity = null;
    this.floor = null;
    this.roomType = '';
  }
}