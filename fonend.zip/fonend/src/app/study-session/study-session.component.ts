import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-study-session',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule],
  templateUrl: './study-session.component.html',
  styleUrl: './study-session.component.css'
})
export class StudySessionComponent implements OnInit {
  studySessions: any[] = [];
  newSession: any = {};
  isEditing: boolean = false;
  sessionToEdit: any = null;
  toastr: any;

  constructor(private apiService: ApiService,) { }

  ngOnInit(): void {
    this.loadStudySessions();
  }

  // Load existing study sessions
  loadStudySessions() {
    this.apiService.get('study_sessions').subscribe(
      (data: any) => {
        this.studySessions = data;
      },
      (error) => {
        this.toastr.error('Failed to load study sessions');
      }
    );
  }

  // Add a new study session
  addStudySession() {
    this.apiService.create('study_sessions', this.newSession).subscribe(
      (response) => {
        this.toastr.success('Study session added successfully');
        this.loadStudySessions(); // Reload sessions
        this.newSession = {}; // Reset form
      },
      (error) => {
        this.toastr.error('Failed to add study session');
      }
    );
  }

  // Edit a study session (populate form with session data)
  editSession(session: any) {
    this.isEditing = true;
    this.newSession = { ...session }; // Copy session data to form
    this.sessionToEdit = session; // Store the session to edit
  }

  // Update the existing study session
  updateStudySession() {
    this.apiService.update('study_sessions', this.sessionToEdit.id, this.newSession).subscribe(
      (response) => {
        this.toastr.success('Study session updated successfully');
        this.loadStudySessions(); // Reload sessions
        this.newSession = {}; // Reset form
        this.isEditing = false; // Reset edit mode
      },
      (error) => {
        this.toastr.error('Failed to update study session');
      }
    );
  }

  // Delete a study session
  deleteSession(sessionId: number) {
    this.apiService.delete('study_sessions', sessionId).subscribe(
      (response) => {
        this.toastr.success('Study session deleted successfully');
        this.loadStudySessions(); // Reload sessions
      },
      (error) => {
        this.toastr.error('Failed to delete study session');
      }
    );
  }
}