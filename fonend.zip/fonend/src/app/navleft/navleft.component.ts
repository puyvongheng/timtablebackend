import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzIconModule, NzIconService } from 'ng-zorro-antd/icon';
import { NzMessageService } from 'ng-zorro-antd/message';

import { FileTextOutline, FolderOutline, HomeOutline, InsertRowAboveOutline, PieChartOutline, PlusOutline, SolutionOutline, TeamOutline, UserOutline } from '@ant-design/icons-angular/icons';



@Component({
  selector: 'app-navleft',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, NzMenuModule, NzSwitchModule, NzIconModule, NzToolTipModule],
  templateUrl: './navleft.component.html',
  styleUrl: './navleft.component.css'
})
export class NavleftComponent {


  constructor(
    private iconService: NzIconService,
    private message: NzMessageService
  ) {
    this.iconService.addIcon(
      UserOutline,
      HomeOutline,
      PieChartOutline,
      InsertRowAboveOutline,
      PlusOutline,
      SolutionOutline,
      FolderOutline,
      TeamOutline,
      FileTextOutline
    );
  }


  isCollapsed = true;


  toggleCollapsed(): void {
    this.isCollapsed = !this.isCollapsed;
  }


}
