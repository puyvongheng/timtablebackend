import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-27LHSJWP.js";
import "./chunk-QQPMNSE3.js";
import "./chunk-TXDUYLVM.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
