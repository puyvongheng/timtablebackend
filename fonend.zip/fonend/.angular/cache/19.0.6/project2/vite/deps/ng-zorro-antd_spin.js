import {
  NzSpinComponent,
  NzSpinModule
} from "./chunk-AWGD7O4B.js";
import "./chunk-Y7O6DRCY.js";
import "./chunk-UNNR4FNV.js";
import "./chunk-MCWHTXE5.js";
import "./chunk-CQ7AE3R3.js";
import "./chunk-QQPMNSE3.js";
import "./chunk-TXDUYLVM.js";
export {
  NzSpinComponent,
  NzSpinModule
};
//# sourceMappingURL=ng-zorro-antd_spin.js.map
