import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-MGIYUBGG.js";
import "./chunk-4PKU5SAB.js";
import "./chunk-ZCGKYO3B.js";
import "./chunk-AOWV25HA.js";
import "./chunk-VL6ISAES.js";
import "./chunk-KBGZVJGK.js";
import "./chunk-4IICRJDW.js";
import "./chunk-CQ7AE3R3.js";
import "./chunk-QQPMNSE3.js";
import "./chunk-TXDUYLVM.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
