import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-YZ4XW4KG.js";
import "./chunk-2SJ2DHYL.js";
import "./chunk-SJ3NPWEQ.js";
import "./chunk-WUUVWCMF.js";
import "./chunk-VL6ISAES.js";
import "./chunk-UNNR4FNV.js";
import "./chunk-MCWHTXE5.js";
import "./chunk-KBGZVJGK.js";
import "./chunk-4IICRJDW.js";
import "./chunk-CQ7AE3R3.js";
import "./chunk-QQPMNSE3.js";
import "./chunk-TXDUYLVM.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
//# sourceMappingURL=ng-zorro-antd_icon.js.map
