import { Component } from '@angular/core';

@Component({
  selector: 'app-study-sessions',
  imports: [],
  templateUrl: './study-sessions.component.html',
  styleUrl: './study-sessions.component.css'
})
export class StudySessionsComponent {

}
