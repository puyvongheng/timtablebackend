import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ApiService } from '../service/api.service';
import { DeleteOutline, EditOutline, HomeOutline, InsertRowAboveOutline, PieChartOutline, PlusOutline, SolutionOutline, UserOutline } from '@ant-design/icons-angular/icons';
import { NzIconModule, NzIconService } from 'ng-zorro-antd/icon';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';


@Component({
  selector: 'app-faculty',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, NzMenuModule, NzSwitchModule, NzIconModule, NzToolTipModule],
  templateUrl: './faculty.component.html',
  styleUrl: './faculty.component.css'
}) export class FacultyComponent implements OnInit {
  faculties: any[] = []; // Array to hold the faculties
  newFacultyName: string = ''; // Input for new faculty name
  selectedFacultyId: number | null = null; // Selected Faculty ID for editing





  constructor(private apiService: ApiService,
    private iconService: NzIconService,
    private message: NzMessageService) {
    this.iconService.addIcon(UserOutline, HomeOutline, PieChartOutline, DeleteOutline, EditOutline, InsertRowAboveOutline, PlusOutline, SolutionOutline);

  }

  ngOnInit(): void {
    this.loadFaculties(); // Load faculties on component initialization
  }

  // Fetch all faculties
  loadFaculties(): void {
    this.apiService.getFaculties().subscribe((response) => {
      this.faculties = response;
    });
  }

  // Add a new faculty
  addFaculty(): void {
    if (this.newFacultyName.trim()) {
      this.apiService.create('faculties', { name: this.newFacultyName }).subscribe(
        () => {
          this.loadFaculties(); // Reload faculties after successful creation
          this.newFacultyName = ''; // Clear the input field
        },
        (error) => {
          console.error('Error adding faculty:', error);
        }
      );
    } else {
      alert('Please provide a faculty name!');
    }
  }

  // Edit an existing faculty
  editFaculty(id: number): void {
    const faculty = this.faculties.find(fac => fac.id === id);
    if (faculty) {
      this.selectedFacultyId = id;
      this.newFacultyName = faculty.name; // Pre-fill the input field with the faculty's name
    }
  }

  // Update an existing faculty
  updateFaculty(): void {
    if (this.selectedFacultyId && this.newFacultyName.trim()) {
      this.apiService.update('faculties', this.selectedFacultyId, { name: this.newFacultyName }).subscribe(
        () => {
          this.loadFaculties(); // Reload faculties after successful update
          this.newFacultyName = ''; // Clear the input field
          this.selectedFacultyId = null; // Clear the selected faculty ID
        },
        (error) => {
          console.error('Error updating faculty:', error);
        }
      );
    }
  }

  // Delete a faculty
  deleteFaculty(id: number): void {
    if (confirm('Are you sure you want to delete this faculty?')) {
      this.apiService.delete('faculties', id).subscribe(
        () => {
          this.loadFaculties(); // Reload faculties after successful deletion
        },
        (error) => {
          console.error('Error deleting faculty:', error);
        }
      );
    }
  }
}