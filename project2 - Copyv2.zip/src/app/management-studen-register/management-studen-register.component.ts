import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-management-studen-register',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './management-studen-register.component.html',
  styleUrl: './management-studen-register.component.css'
})
export class ManagementStudenRegisterComponent {


  studentForm: FormGroup;
  majors: any[] = []; // To store the list of majors
  showPassword: boolean = false; // Toggle password visibility
  submissionError: string | null = null;
  submissionSuccess: string | null = null;

  constructor(private fb: FormBuilder, private apiService: ApiService) {
    this.studentForm = this.fb.group({
      username: ['', [Validators.required]],
      name: ['', [Validators.required]],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(8),
          Validators.pattern('^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&#])[A-Za-z\\d@$!%*?&#]+$')
        ]
      ],
      major_id: ['', [Validators.required]],
      date_joined: ['', [Validators.required]],
      group_student: ['', [Validators.required]],
      shift_name: ['', [Validators.required]] // New field for shift name

    });
  }

  ngOnInit() {
    this.fetchMajors();





  }

  fetchMajors() {
    this.apiService.get('majors').subscribe(
      (response) => {
        this.majors = response; // Set the majors array with the response
      },
      (error) => {
        console.error('Error loading majors:', error);
        // You can also display an error message to the user here if needed
      }
    );

  }

  // Method to find a major by its ID
  findMajor(majorId: number): any {
    const major = this.majors.find((m) => m.id === majorId);
    return major || { major_name: 'Unknown', department_name: 'Unknown', Departments_id: 'Unknown' };
  }


  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  onSubmit() {


    if (this.studentForm.valid) {
      this.apiService.create('students', this.studentForm.value).subscribe(
        (response) => {
          this.submissionSuccess = response.message;
          this.submissionError = null;
          this.studentForm.reset();  // Clear the form after successful submission
        },
        (error) => {
          this.submissionError = error.error?.error || 'An error occurred. Please try again.';
          this.submissionSuccess = null;
        }
      );
    }




  }




}

