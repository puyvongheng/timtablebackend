import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ManagementTeacherRegisterComponent } from "../management-teacher-register/management-teacher-register.component";

@Component({
  selector: 'app-management-teacher',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, ReactiveFormsModule, ManagementTeacherRegisterComponent],
  templateUrl: './management-teacher.component.html',
  styleUrl: './management-teacher.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line

})
export class ManagementTeacherComponent implements OnInit {
  teachers: any[] = [];
  constructor(private apiService: ApiService, private fb: FormBuilder) {



  }




  ngOnInit(): void {
    this.loadData();
  }








  // Load related data (teachers, majors, rooms, study sessions)
  loadData(): void {
    // Fetch teachers
    this.apiService.get('teachers').subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading teachers:', error)
    );
  }


  Updaterole(teacherId: number, newRole: string): void {
    if (!['admin', 'simple'].includes(newRole)) {
      alert('Invalid role selected.');
      return;
    }

    const confirmUpdate = window.confirm(`Are you sure you want to update the role to "${newRole}"?`);
    if (confirmUpdate) {
      this.apiService.updatrole('teachers', { id: teacherId, role: newRole }).subscribe({
        next: (response) => {
          alert('Role updated successfully.');
          this.loadData(); // Reload data after updating
        },
        error: (err) => {
          alert('Failed to update role.');
          console.error('Error updating role:', err);
        },
      });
    }
  }



}
