import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ManagementStudenRegisterComponent } from "../management-studen-register/management-studen-register.component";
@Component({
  selector: 'app-management-teacher-register',
  imports: [FormsModule, HttpClientModule, CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './management-teacher-register.component.html',
  styleUrl: './management-teacher-register.component.css'
})
export class ManagementTeacherRegisterComponent {

  showPassword: boolean = false; // Toggle for password visibility


  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  constructor(private apiService: ApiService, private fb: FormBuilder) {


    this.teacherForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(4)]],
      name: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(8)]],
      role: ['simple', Validators.required],
    });

  }




  ngOnInit(): void {

  }




  teacherForm: FormGroup;
  submissionSuccess: boolean = false;
  submissionError: string | null = null;


  onSubmit() {
    if (this.teacherForm.valid) {

      this.apiService.create('teachers', this.teacherForm.value).subscribe({
        next: (response) => {
          this.submissionSuccess = true;
          this.submissionError = null;
          this.teacherForm.reset({ role: 'simple' }); // Reset form and default role
        },
        error: (error) => {
          this.submissionSuccess = false;
          this.submissionError = error.error?.error;
        }
      });
    }
  }









}


