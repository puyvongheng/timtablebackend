import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './service/auth.service';
import { NavbarComponent } from "./navbar/navbar.component";
import { NavleftComponent } from "./navleft/navleft.component";
import { NzBreadCrumbModule } from 'ng-zorro-antd/breadcrumb';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, CommonModule, NavbarComponent, NavleftComponent, NzBreadCrumbModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  // Define any properties you need in this component


  teacherDetails: any = null; // To store student details after successful login



  constructor(private authService: AuthService) { }

  // ngOnInit lifecycle hook
  ngOnInit(): void {






    // Get student details from localStorage (or sessionStorage)
    const storedteacherDetails = localStorage.getItem('teacherDetails');
    if (storedteacherDetails) {
      this.teacherDetails = JSON.parse(storedteacherDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }


    // For example, you might want to check if a user is already logged in

  }

}