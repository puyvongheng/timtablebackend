import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { EditTimetableComponent } from "../edit-timetable/edit-timetable.component";
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule, NzSelectSizeType } from 'ng-zorro-antd/select';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzPopoverModule } from 'ng-zorro-antd/popover';
import { presetColors } from 'ng-zorro-antd/core/color';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzIconModule, NzIconService } from 'ng-zorro-antd/icon';

import { DeleteOutline, EditOutline, HomeOutline, InsertRowAboveOutline, PieChartOutline, PlusOutline, SolutionOutline, UserOutline } from '@ant-design/icons-angular/icons';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzSkeletonModule } from 'ng-zorro-antd/skeleton';



@Component({
  selector: 'app-timetables',
  imports: [
    FormsModule,
    NzSkeletonModule,
    HttpClientModule,
    NzTagModule,
    NzButtonModule,
    NzPopoverModule,
    CommonModule,
    RouterModule,
    RouterModule,
    NzIconModule,

    NzSelectModule,
    NzToolTipModule,
    NzModalModule,
    NzRadioModule,],
  templateUrl: './timetables.component.html',
  styleUrls: ['./timetables.component.css'],
})
export class TimetablesComponent implements OnInit {
  timetables: any[] = []; // Array to hold timetable data
  teachers: any[] = []; // Array to hold teachers data
  majors: any[] = []; // Array to hold majors data
  rooms: any[] = []; // Array to hold rooms data
  studySessions: any[] = []; // Array to hold study sessions data
  isLoading: boolean = false; // Indicator for data loading
  message: any; // Replace with a proper message service if needed



  filterDay: string = '';
  filterTeacher: string = '';
  filterBatch: string = '';
  filterGeneration: string = '';
  filterGroupStudent: string = '';
  filterSemester: string = '';
  filterYear: string = '';
  filterStudyShift: string = '';
  filterMajorName: string = '';
  filterRoom: string = '';


  constructor(
    private apiService: ApiService,
    private router: Router,
    private iconService: NzIconService,
    private modal: NzModalService
  ) {
    this.iconService.addIcon(
      UserOutline,
      HomeOutline,
      PieChartOutline,
      InsertRowAboveOutline,
      PlusOutline,
      SolutionOutline,
      DeleteOutline,
      EditOutline


    );

  }

  ngOnInit(): void {

    this.loadData();
    this.loadTimetables();//simple timetable   all data 
    //  this.loadTimetablesgroup();//group time table 
    const currentYear = new Date().getFullYear();
    this.filterYear = currentYear.toString(); // Assign current year as string



  }





  get uniqueRoom() {
    const rooms = this.timetables.map(t => t.room_number);
    return [...new Set(rooms)];
  }
  get uniqueYears() {
    const years = this.timetables.map(t => t.years);
    return [...new Set(years)];
  }
  get uniqueStudyShifts() {
    const studyShifts = this.timetables.map(t => t.
      study_shift_name);
    return [...new Set(studyShifts)];
  }
  get uniqueGroupStudents() {
    const groupStudents = this.timetables.map(t => t.group_student);
    return [...new Set(groupStudents)];
  }
  get uniqueSemesters() {
    const semesters = this.timetables.map(t => t.semester);
    return [...new Set(semesters)];
  }
  get uniqueGenerations() {
    const generations = this.timetables.map(t => t.generation);
    return [...new Set(generations)];
  }
  get uniqueMajors() {
    const majors = this.timetables.map(t => t.major_name);
    return [...new Set(majors)];
  }
  get uniqueBatch() {
    const batches = this.timetables.map(t => t.batch);
    return [...new Set(batches)];
  }
  get uniqueTeachers() {
    // Extract unique teacher IDs from timetables and map them to teacher names
    const teacherIds = [...new Set(this.timetables.map(t => t.teacher_id))];
    return teacherIds.map(id => ({
      id,
      name: this.findTeacher(id),
    }));
  }








  /*
  
    // Group timetable entries by time and day
    groupTimetablesByTimeAndDay(timetables: any[]): any[] {
      const grouped: any[] = [];
  
      timetables.forEach((entry) => {
        const { session_time_start, session_time_end, study_sessions_id, study_session_day, subject_name, teacher_id, room_id, id } = entry;
  
        // Find the time slot in the grouped array
        const timeSlot = grouped.find((slot) => slot.time === `${session_time_start} - ${session_time_end}`);
  
        if (timeSlot) {
          // If the time slot exists, add the entry under the corresponding day
          timeSlot[study_session_day] = { subject_name, teacher_id, room_id, study_sessions_id, id };
        } else {
          // If the time slot doesn't exist, create a new time slot entry
          grouped.push({
            time: `${session_time_start} - ${session_time_end}`,
            [study_session_day]: { subject_name, teacher_id, room_id, study_sessions_id, id }
          });
        }
      });
  
      return grouped;
    }
  
  */





  // Method to filter timetables based on the filter criteria
  filterTimetables(): void {
    this.isLoading = true

    let filteredTimetables = this.timetables;


    if (this.filterTeacher) {
      filteredTimetables = filteredTimetables.filter(entry =>
        this.findTeacher(entry.teacher_id).toLowerCase().includes(this.filterTeacher.toLowerCase()));
    }
    // Filter by study shift name
    if (this.filterStudyShift) {
      filteredTimetables = filteredTimetables.filter(entry =>
        entry.study_shift_name.toLowerCase().includes(this.filterStudyShift.toLowerCase()));
    }
    // Filter based on batch
    if (this.filterBatch) {
      filteredTimetables = filteredTimetables.filter(entry => entry.batch.toString() === this.filterBatch);
    }
    // Filter based on generation
    if (this.filterGeneration) {
      filteredTimetables = filteredTimetables.filter(entry => entry.generation.toString() === this.filterGeneration);
    }
    // Filter based on group_student
    if (this.filterGroupStudent) {
      filteredTimetables = filteredTimetables.filter(entry => entry.group_student.toString() === this.filterGroupStudent);
    }
    // Filter based on semester
    if (this.filterSemester) {
      filteredTimetables = filteredTimetables.filter(entry => entry.semester.toString() === this.filterSemester);
    }

    // Filter based on year
    if (this.filterYear) {
      filteredTimetables = filteredTimetables.filter(entry => entry.years.toString() === this.filterYear);
    }

    // Filter based on major_name
    if (this.filterRoom) {
      filteredTimetables = filteredTimetables.filter(entry => entry.room_number.toString() === this.filterRoom);
    }

    if (this.filterMajorName) {
      filteredTimetables = filteredTimetables.filter(entry => entry.major_name.toString() === this.filterMajorName);
    }

    // Group by time and day after filtering
    this.groupedTimetables = this.groupTimetablesByTimeAndDay(filteredTimetables);
    this.isLoading = false
  }


  groupTimetablesByTimeAndDay(timetables: any[]): any[] {
    this.isLoading = true
    if (!timetables || timetables.length === 0) return []; // Handle empty input​​​ ​Saturday​ Sunday  "​Saturday​"

    const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    const grouped: any[] = [];

    timetables.forEach((entry) => {
      const {
        session_time_start,
        session_time_end,
        study_session_day,
        study_sessions_id,
        study_shift_name,
        subject_name,
        teacher_id,
        room_id,
        room_number,
        id,
        major_name,
        generation,
        batch,

      } = entry;

      if (!validDays.includes(study_session_day)) return; // Skip invalid days

      const timeRange = `${session_time_start} - ${session_time_end} `;

      // Check if the time slot exists in the grouped array
      let timeSlot = grouped.find((slot) => slot.time === timeRange);

      if (!timeSlot) {
        // If not found, create a new time slot entry
        timeSlot = { time: timeRange };
        grouped.push(timeSlot);
      }

      // Add the entry under the corresponding day
      timeSlot[study_session_day] = {
        subject_name,
        teacher_id,
        room_id,
        study_sessions_id,
        study_shift_name,
        generation,
        room_number,
        batch,
        major_name,
        id,
      };
    });

    // Optionally sort the grouped array by time for better presentation
    grouped.sort((a, b) => {
      const [aStart] = a.time.split(" - ");
      const [bStart] = b.time.split(" - ");
      return new Date(`1970/01/01 ${aStart}`).getTime() - new Date(`1970/01/01 ${bStart}`).getTime();
    });
    this.isLoading = false

    return grouped;
  }
  groupedTimetables: any[] = [];
  formatTime(time: string): string {
    const [hours, minutes] = time.split(':');
    const period = +hours >= 12 ? 'PM' : 'AM';
    const formattedHours = +hours > 12 ? +hours - 12 : +hours;
    return `${formattedHours}:${minutes} ${period}`;
  }







  // Load related data (teachers, majors, rooms, study sessions)
  loadData(): void {
    this.isLoading = true;
    // Fetch teachers
    this.apiService.get('teachers').subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading teachers:', error)
    );
    // Fetch majors
    this.apiService.get('majors').subscribe(
      (response) => (this.majors = response),
      (error) => console.error('Error loading majors:', error)
    );

    // Fetch rooms
    this.apiService.get('rooms').subscribe(
      (response) => (this.rooms = response),
      (error) => console.error('Error loading rooms:', error)
    );
    // Fetch study sessions
    this.apiService.get('study_sessions').subscribe(
      (response) => (this.studySessions = response),
      (error) => console.error('Error loading study sessions:', error)
    );

  }
  // Fetch all timetables  
  loadTimetables(): void {
    this.isLoading = true
    this.apiService.get('timetable').subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = false;
      }
    );
  }


  loadTimetablesgroup(): void {
    this.isLoading = true
    this.apiService.get('timetable').subscribe(
      (response) => {
        this.timetables = response.timetable_entries || response;
        this.isLoading = false;

        // Grouping by time and day
        this.groupedTimetables = this.groupTimetablesByTimeAndDay(this.timetables);
      },
      (error) => {
        console.error('Error loading timetables:', error);
        this.message?.error('Failed to load timetables');
        this.isLoading = true;
      }
    );
  }




  // Find teacher name by ID
  findTeacher(teacherId: number): string {
    const teacher = this.teachers.find((t) => t.id === teacherId);
    return teacher ? teacher.name : 'Unknown';
  }
  // Find room details by ID
  findRoom(roomId: number): any {
    return this.rooms.find((r) => r.id === roomId) || { room_type: 'Unknown', room_number: 'Unknown', floor: 'Unknown', capacity: 'Unknown' };
  }
  findStudySession(sessionId: number): any | null {
    const session = this.studySessions.find((s) => s.id === sessionId);
    return session || null;
  }


  // Find subject name by ID
  findSubject(subjectId: number): string {
    const subject = this.majors.find((s) => s.id === subjectId);
    return subject ? subject.major_name : 'Unknown';
  }




  // edit 
  editTimetable(timetableId: number): void {
    this.router.navigate([`/timetables/edit`, timetableId]);
  }
  // delet 
  deleteTimetable(id: number): void {
    // Show Ant Design modal for confirmation
    this.modal.confirm({
      nzTitle: 'Are you sure you want to delete this ?',
      nzContent: '<b style="color: red;">     .</b>',
      nzOkText: 'Yes',
      nzOkType: 'primary',
      nzOkDanger: true,
      nzOnOk: () => {
        // Delete timetable when user confirms
        this.apiService.delete('timetable', id).subscribe(
          () => {
            // Successfully deleted, reload timetables

            this.loadTimetables();
            this.loadTimetablesgroup();
            this.filterTimetables()


            // Show success message
            this.message?.success('Timetable deleted successfully.');
          },
          (error) => {
            // Handle deletion error
            console.error('Error deleting timetable:', error);
            this.message?.error('Failed to delete timetable.');
          }
        );
      },
      nzCancelText: 'No',
      nzOnCancel: () => console.log('Delete action cancelled'),
    });
  }




}
