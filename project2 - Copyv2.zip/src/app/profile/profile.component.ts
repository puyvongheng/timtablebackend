import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterModule } from '@angular/router';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { AuthService } from '../service/auth.service';
import { ApiService } from '../service/api.service';
import { Observable } from 'rxjs';
import { NzModalModule, NzModalService } from 'ng-zorro-antd/modal';
import { NzSkeletonModule } from 'ng-zorro-antd/skeleton';



@Component({
  selector: 'app-profile',
  imports: [FormsModule, HttpClientModule, NzSkeletonModule, NzModalModule, CommonModule, RouterModule, NzMenuModule,],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent implements OnInit {


  studentDetails: any = null;
  teacherDetails: any = null;
  teachers: any = null;
  majors: any;
  rooms: any;
  studySessions: any;
  teacher_subjects: any[] = [];


  constructor(private authService: AuthService, private apiService: ApiService, private modal: NzModalService) { }




  ngOnInit() {
    this.loadstudentDetails();
    this.loadteacherDetails();
    this.loadData()
  }


  gotologin() {
    window.location.href = '/login';  // This will navigate to the /home route

  }




  teacherss: any[] = [];
  subjects: any[] = [];
  teacher_subjectss: any[] = [];
  selectedSubjectId: { [key: number]: number } = {};


  findMajor(majorId: number): any {
    const major = this.majors.find((m: { id: number; }) => m.id === majorId);
    return major || {
      major_name: 'Unknown',
      department_name: 'Unknown',
      Departments_id: 'Unknown'
    };
  }


  departments: any[] = [];

  findDepartment(departmentId: number): any {
    const department = this.departments.find((s) => s.id === departmentId);
    return department || null;  // Return department object or null if not found
  }



  assignSubjectToTeacher(teacherId: number, subjectId: number): void {

    this.apiService.assignSubjectToTeacher(teacherId, subjectId).subscribe(
      (response) => {
        console.log('Subject assigned successfully:', response);
        // Optionally, show a success message or update the UI
        this.loadData()
      },
      (error) => {
        console.error('Error assigning subject to teacher:', error);
        // Handle error appropriately, maybe show an error message
      }
    );
  }


  removeSubjectFromTeachers(teacherId: number, subjectId: number): void {
    // Show confirmation modal before removing subject
    this.modal.confirm({
      nzTitle: 'Are you sure you want to remove this subject from the teacher?',
      nzContent: `Teacher ID: ${teacherId}, Subject ID: ${subjectId}`,
      nzOnOk: () => {
        // If confirmed, call API to delete the association
        this.apiService.deleteTeacherSubject(teacherId, subjectId).subscribe(
          response => {
            console.log('Teacher-Subject association deleted:', response);
            this.loadData(); // Refresh the data to reflect the change
          },
          error => {
            console.error('Error removing teacher-subject association:', error);
          }
        );
      },
      nzOnCancel: () => {
        this.loadData(); // Refresh the data to reflect the change
        console.log('Operation cancelled');
      }
    });
  }


  removeSubjectFromTeacher(teacherId: number, subjectId: number): void {
    this.apiService.deleteTeacherSubject(teacherId, subjectId).subscribe(
      response => {
        console.log('Teacher-Subject association deleted:', response);
        this.loadData(); // Refresh the data to reflect the change
      },
      error => {
        console.error('Error removing teacher-subject association:', error);
      }
    );
  }





  findSubject(teacherId: number): { subject_name: string, id: number }[] {
    // Filter subjects based on teacher_id
    const teacherSubjects = this.teacher_subjects.filter((subject) => subject.teacher_id === teacherId);

    // If subjects found, return an array of objects with subject_name and id
    return teacherSubjects.length > 0
      ? teacherSubjects.map(subject => ({
        subject_name: subject.subject_name, id: subject.subject_id
      }))
      : [{ subject_name: 'No subjects found for this teacher', id: -1 }];
  }


  // Handle subject selection from the dropdown
  onSubjectSelect(event: any, teacherId: number): void {
    this.selectedSubjectId[teacherId] = +event.target.value; // Store the selected subject ID
  }


  findSubjectName(subjectId: number): string {
    const subject = this.subjects.find((s) => s.id === subjectId);
    return subject ? subject.name : 'Unknown';
  }






  loadData(): void {
    // Fetch teachers


    // Fetch teachers
    this.apiService.get('teachers').subscribe(
      (response) => (this.teachers = response),
      (error) => console.error('Error loading teachers:', error)
    );

    this.apiService.get('teacher_subjects').subscribe(
      (response) => (this.teacher_subjects = response),
      (error) => console.error('Error loading teachers:', error)
    );


    this.apiService.get('subjects').subscribe(
      (response) => {
        this.subjects = response;
      },
      (error) => {
        console.error('Error loading subjects:', error);
      }
    );

    this.apiService.get('majors').subscribe(
      (response) => {
        this.majors = response;
      },
      (error) => {
        console.error('Error loading subjects:', error);
      }
    );




  }

  // Calculate year minus 2007
  getYearMinus2007() {
    const date = this.studentDetails.date_joined ? new Date(this.studentDetails.date_joined) : null;
    if (date) {
      return date.getFullYear() - 2007; // Subtract 2007 from the year
    }
    return 0;
  }
  getYear() {
    // Make sure that 'this.yyyynow' is a valid Date object.
    const currentDate = new Date(); // Get the current date
    return currentDate.getFullYear() - 2007; // Subtract 2007 from the current year
  }

  loadstudentDetails() {
    // Get student details from localStorage (or sessionStorage)
    const storedStudentDetails = localStorage.getItem('studentDetails');
    if (storedStudentDetails) {
      this.studentDetails = JSON.parse(storedStudentDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }
  }

  loadteacherDetails() {
    const storedTeacherDetails = localStorage.getItem('teacherDetails');
    if (storedTeacherDetails) {
      this.teacherDetails = JSON.parse(storedTeacherDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }
  }
}

