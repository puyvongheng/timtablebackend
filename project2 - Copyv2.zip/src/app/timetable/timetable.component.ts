import { Component, OnInit } from '@angular/core';
import { TimetableService } from '../service/timetable.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-timetable',
  imports: [FormsModule, HttpClientModule, CommonModule],
  templateUrl: './timetable.component.html',
  styleUrl: './timetable.component.css'
}) export class TimetableComponent implements OnInit {
  timetableEntries: any[] = [];
  majors: any[] = [];
  studySessions: any[] = [];  // To store the shift names
  uniqueShiftNames: string[] = [];  // New array to hold unique shift names

  filters = {
    majorId: '',
    batch: '',
    years: null,
    semester: null,
    generation: '',
    shiftName: ''
  };

  constructor(private timetableService: TimetableService) { }

  ngOnInit(): void {
    this.loadMajors();
    this.loadStudySessions();  // Fetch shift names on component initialization

  }

  loadMajors(): void {
    this.timetableService.getMajors().subscribe(
      (data) => (this.majors = data),
      (error) => console.error('Error loading majors', error)
    );
  }

  loadStudySessions(): void {
    this.timetableService.getStudySessions().subscribe(
      (data) => {
        this.studySessions = data;
        // Remove duplicates by creating a Set of shift names
        this.uniqueShiftNames = Array.from(new Set(this.studySessions.map(session => session.shift_name)));
      },
      (error) => console.error('Error loading study sessions', error)
    );
  }


  loadTimetable(): void {
    const { majorId, batch, years, semester, generation, shiftName } = this.filters;
    this.timetableService
      .getTimetable(
        majorId,
        batch,
        years !== null ? years : undefined, // Use undefined if years is null
        semester !== null ? semester : undefined, // Use undefined if semester is null
        generation,
        shiftName
      )
      .subscribe(
        (data) => (this.timetableEntries = data.timetable_entries),
        (error) => console.error('Error loading timetable', error)
      );
  }



}