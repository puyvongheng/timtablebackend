import { Component } from '@angular/core';
import { AuthService } from '../service/auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzSpinModule } from 'ng-zorro-antd/spin';

@Component({
  selector: 'app-login',
  imports: [FormsModule, HttpClientModule, CommonModule, NzAlertModule, NzSpinModule, RouterModule,],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  username: string = '';
  password: string = '';
  studentDetails: any = null;  // To store student details after successful login

  isLoading: boolean = false;  // Flag to control the spinner visibility

  loginStatus: string | null = null;
  alertType: 'success' | 'error' = 'success'; // C
  errors: string[] = []; // Array to hold error messages


  constructor(private authService: AuthService, private router: Router) { }


  home(): void {
    //  this.router.navigate(['/home']);
    window.location.href = '/Profile';  // This will navigate to the /home route

  }

  // Method to handle login
  login() {
    // Make the login request using the AuthService
    this.authService.login(this.username, this.password).subscribe(
      (response) => {
        // If login is successful
        this.studentDetails = response.user;  // Store user details in memory
        localStorage.setItem('studentDetails', JSON.stringify(response.user));


        this.loginStatus = 'Login successful!';
        this.alertType = 'success';

        this.isLoading = true;  // Start showing the spinner


        setTimeout(() => {
          this.isLoading = false;  // Hide the spinner after 10 seconds
          this.home()

        }, 1000); // 10 seconds = 10000 milliseconds


      },
      (error) => {
        const errorMessage = error.error?.error || 'Login failed'; // Adjusted based on the backend error response
        this.errors.push(errorMessage); // Add error message to errors array
        this.alertType = 'error';
        this.loginStatus = errorMessage; // Update status to show the error message
      }
    );
  }
}