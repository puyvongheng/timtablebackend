import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ManagementComponent } from '../management/management.component';
import { DepartmentComponent } from "../department/department.component";
import { FacultyComponent } from '../faculty/faculty.component';
import { MajorComponent } from '../major/major.component';
import { RoomComponent } from '../room/room.component';
import { TimetableComponent } from "../timetable/timetable.component";

@Component({
  selector: 'app-dashboard',
  imports: [


  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Add this line

})
export class DashboardComponent {

}
