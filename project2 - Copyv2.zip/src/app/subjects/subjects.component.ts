import { CommonModule } from '@angular/common';
import { ApiService } from './../service/api.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, isFormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-subjects',
  imports: [CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './subjects.component.html',
  styleUrl: './subjects.component.css'
})
export class SubjectsComponent implements OnInit {
  subjects: { id: number; name: string }[] = [];
  subjectForm: FormGroup;

  constructor(private apiService: ApiService, private fb: FormBuilder) {
    this.subjectForm = this.fb.group({
      name: ['', Validators.required], // Form control with validation
    });
  }

  ngOnInit(): void {
    this.loadData();
  }


  loadData(): void {
    this.apiService.get('subjects').subscribe(
      (response) => (this.subjects = response),
      (error) => console.error('Error loading data:', error)
    );
  }

  addSubject(): void {
    if (this.subjectForm.valid) {
      const newSubject = this.subjectForm.value;
      this.apiService.create('subjects', newSubject).subscribe(
        (response) => {
          this.subjects.push(response); // Add the new subject to the list
          this.subjectForm.reset(); // Clear the form
          this.loadData()
        },
        (error) => console.error('Error adding subject:', error)
      );
    }
  }

  deleteSubject(id: number): void {
    const confirmation = window.confirm('Are you sure you want to delete this subject?');
    if (confirmation) {
      this.apiService.delete('subjects', id).subscribe(
        () => {
          this.subjects = this.subjects.filter((subject) => subject.id !== id); // Remove the deleted subject from the list
          this.loadData()
        },
        (error) => console.error('Error deleting subject:', error)
      );
    }
  }


}