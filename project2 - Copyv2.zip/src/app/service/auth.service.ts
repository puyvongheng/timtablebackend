import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = `https://puyvongheng.online/api/students`;  // Adjust the API URL according to your backend
  private apiUrlteachers = `https://puyvongheng.online/api/teachers`;  // Adjust the API URL according to your backend

  constructor(private http: HttpClient, private router: Router) { }

  // Login method for  studen
  login(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/login`, { username, password });
  }
  //login tacher
  login_tacher(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrlteachers}/login`, { username, password });
  }


  // Logout method
  logout() {
    localStorage.removeItem('token');  // Remove the token from localStorage
    localStorage.removeItem('studentDetails');  // Remove user details from localStorage
    localStorage.removeItem('teacherDetails');  // Remove user details from localStorage
    //  window.location.reload();  // This reloads the page

    // this.router.navigate(['/login']);  // Redirect user to login page
    this.router.navigate(['/login']);

    setTimeout(() => {
      window.location.reload();  // Reload the page
      this.router.navigate(['/login']);  // Redirect user to the login page
    }, 100);  // 10-second delay before reloading and navigating
    //  window.location.reload();

  }


}
