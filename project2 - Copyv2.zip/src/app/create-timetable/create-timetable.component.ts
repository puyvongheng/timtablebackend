import { Component, OnInit } from '@angular/core';
import { TimetableService } from '../service/timetable.service';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm, NgModel } from '@angular/forms';


interface StudySession {
  id: string;
  shift_name: string;
  sessions_day: string;
  session_time_start: string;
  session_time_end: string;
}


interface Major {
  id: string;
  major_name: string;
}

interface Teacher {
  id: string;
  name: string;
}

interface Subject {
  id: string;
  name: string;
}

interface Room {
  id: string;
  room_number: string;
}

@Component({
  selector: 'app-create-timetable',
  imports: [CommonModule, FormsModule],
  templateUrl: './create-timetable.component.html',
  styleUrl: './create-timetable.component.css'
})
export class CreateTimetableComponent implements OnInit {
  timetableForm = {
    note: '',
    study_sessions_id: '',
    group_student: '',
    batch: '',
    generation: '',
    major_id: '',
    teacher_id: '',
    subject_id: '',
    room_id: '',
    years: '',
    semester: ''
  };
  message: string = '';
  messages: string[] = [];
  alertClass: string = '';
  studySessions: StudySession[] = [];

  majors: Major[] = [];
  teachers: Teacher[] = [];
  subjects: Subject[] = [];
  rooms: Room[] = [];
  isLoading: boolean = false; // Indicator for data loading


  teacherDetails: any = null; // To store student details after successful login

  constructor(private timetableService: TimetableService) { }

  ngOnInit(): void {
    this.timetableForm.years = new Date().getFullYear().toString();


    const storedteacherDetails = localStorage.getItem('teacherDetails');
    if (storedteacherDetails) {
      this.teacherDetails = JSON.parse(storedteacherDetails);
    } else {
      // Handle the case if no student details are found in storage
      console.error("No student details found.");
    }

    this.loadDropdownData();
  }


  shiftName: string = '';
  sessionDay: string = '';
  sessionTime: string = '';

  // Method to filter the sessions based on selected filters
  // Get unique shift names
  getUniqueShiftNames() {
    const shifts = this.studySessions.map(session => session.shift_name);
    return [...new Set(shifts)];
  }



  getUniqueDaysForShift() {
    // Filter sessions based on the selected shift and return unique days
    if (!this.shiftName) return []; // If no shift selected, return empty array
    const filteredSessions = this.studySessions.filter(session => session.shift_name === this.shiftName);
    const days = filteredSessions.map(session => session.sessions_day);
    return [...new Set(days)];
  }

  // Get unique session times
  /*
  getUniqueTimes() {
    
    const times = this.studySessions.map(session => session.session_time_start);
    return [...new Set(times)];
  }
*/

  // Get unique session times for a selected shift and day
  getUniqueTimes() {
    if (!this.shiftName || !this.sessionDay) return []; // If no shift or day selected, return empty array
    // Filter sessions based on shiftName and sessionDay
    const filteredSessions = this.studySessions.filter(session =>
      session.shift_name === this.shiftName && session.sessions_day === this.sessionDay);

    // Get unique start times
    const times = filteredSessions.map(session => session.session_time_start);
    return [...new Set(times)];
  }

  // Filter sessions based on selected shift, day, and time
  getFilteredSessions() {
    return this.studySessions.filter(session => {
      const matchesShiftName = this.shiftName ? session.shift_name.includes(this.shiftName) : true;
      const matchesSessionDay = this.sessionDay ? session.sessions_day === this.sessionDay : true;
      const matchesSessionTime = this.sessionTime ? session.session_time_start === this.sessionTime : true;
      return matchesShiftName && matchesSessionDay && matchesSessionTime;
    });
  }

  // Automatically select the first session ID based on filtered sessions
  updateSelectedSession() {
    const filteredSessions = this.getFilteredSessions();
    if (filteredSessions.length > 0) {
      this.timetableForm.study_sessions_id = filteredSessions[0].id; // Automatically set the first session
    } else {
      this.timetableForm.study_sessions_id = ''; // Reset to empty string if no session found
    }

    if (!this.shiftName) {
      this.sessionDay = '';  // Reset sessionDay
      this.sessionTime = ''; // Reset sessionTime
    } else {
      // You can add any additional filtering logic here if needed
    }

  }






  loadDropdownData() {
    this.timetableService.getStudySessions().subscribe((data) => (this.studySessions = data));
    this.timetableService.getMajors().subscribe((data) => (this.majors = data));
    this.timetableService.getTeachers().subscribe((data) => (this.teachers = data));
    this.timetableService.getSubjects().subscribe((data) => (this.subjects = data));
    this.timetableService.getRooms().subscribe((data) => (this.rooms = data));
  }





  // This method is called when the form is submitted
  onSubmit(): void {
    this.isLoading = true; // Indicator for data loading

    this.messages = []; // Clear previous messages
    this.timetableService.createTimetable(this.timetableForm).subscribe(
      (response: any) => {
        if (response.errors) {
          // If there are multiple errors, display them all
          this.messages = response.errors.map((err: { error: string }) => err.error);
          console.log("Errors from the backend:", response.errors); // Debug log
          this.isLoading = false; // Indicator for data loading

        } else if (response.message) {
          // If the API returns a success message
          this.messages.push(response.message);
        }
      },
      (error) => {


        if (error.error && error.error.errors) {
          this.messages = error.error.errors.map((err: { error: string }) => err.error);
        } else {
          // If there's a network or other error, show a generic error message
          this.messages.push('An error occurred. Please try again later.');
          this.isLoading = false; // Indicator for data loading
        }
        
        // If there is a network or server error, show a generic error message
        this.messages.push('An error occurred. Please try again later.');
        console.error('Error creating timetable:', error);
        this.isLoading = false; // Indicator for data loading

      }
    );
  }


  resetForm(): void {
    this.timetableForm = {
      note: '',
      study_sessions_id: '',
      group_student: '',
      batch: '',
      generation: '',
      major_id: '',
      teacher_id: '',
      subject_id: '',
      room_id: '',
      years: '',
      semester: ''
    };
  }

}