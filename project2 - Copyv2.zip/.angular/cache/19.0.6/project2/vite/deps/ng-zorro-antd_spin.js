import {
  NzSpinComponent,
  NzSpinModule
} from "./chunk-PWMQDJGO.js";
import "./chunk-O5EAZA5P.js";
import "./chunk-YCFIURYJ.js";
import "./chunk-AWUYWLN6.js";
import "./chunk-F7VJLCZX.js";
import "./chunk-7LSXWQD5.js";
import "./chunk-WDMUDEB6.js";
export {
  NzSpinComponent,
  NzSpinModule
};
//# sourceMappingURL=ng-zorro-antd_spin.js.map
